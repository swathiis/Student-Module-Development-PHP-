<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>

		<script>
			$(document).ready(function(){
				$(".submit").click(function(){
					var name= $('#name').val();
					if (name==""){
						alert("please enter your name");
						return false;
					}
				});
			});
			
		</script>
	</head>
	<body>
		<form action="form_prc.php" method="POST">
			id:<input type="text" name="id" id="id"><br>
			name:<input type="text" name="name" id="name"><br>
			salary:<input type="text" name="salary" id="salary"><br>
			<input type="submit" id="submit" value="submit">
		</form>
	</body>
</html>
