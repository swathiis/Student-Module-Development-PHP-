<?php
include 'database_connection.php';
$id = $_GET['id'];
$sql="select * from students where roll_no ='".$id."'";
$res = mysqli_query($con,$sql);
$row = mysqli_fetch_array($res);

?>

<html>
	<div>
		<h1>STUDENTS</h1>
	</div>
	<body>
	<form action="edit_prc.php" method="POST">
		<table>
			<tr>
				<td>Roll.No:</td>
				<td><input type="text" name="rollno" value="<?php echo $row['roll_no'];?>" readonly></td>
			</tr>
			<tr>
				<td>Name:</td>
				<td><input type="text" name="name" value="<?php echo $row['name'];?>"></td>
			</tr>
			<tr>
				<td>Phone No:</td>
				<td><input type="text" name="phoneno" value="<?php echo $row['phone'];?>"></td>
			</tr>
			<tr>
				<td>Department:</td>
				<td>
					<select name="dept">
						<option>CSE</option>
						<option>B.Tech</option>
						<option>BCA</option>
					</select>
				</td>
			</tr>
			<tr>
				<td>Address:</td>
				<td><textarea name="address"><?php echo $row['address'];?></textarea></td>
			</tr>
			<tr>
				<td><input type="submit" value="submit"></td>
			</tr>
		</table>
		</form>
	</body>
	
</html>