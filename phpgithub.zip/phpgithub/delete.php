<?php
include 'database_connection.php';
$id = $_GET['id'];
$sql="delete from students where roll_no ='".$id."'";
$res = mysqli_query($con,$sql);
$row = mysqli_fetch_array($res);

header("Location:view.php");
?>