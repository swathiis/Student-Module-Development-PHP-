
	<head>
		<script>
		function validate()
		{
		 var id=document.getElementById('id').value;
		 if(id==""){
			 alert("please enter your ID");
		 }
		 
		 var name=document.getElementById('name').value;
		 if(name==""){
			 alert("please enter your Name");
			 return false;
		 }
		 var salary=document.getElementById('salary').value;
		 if(salary==""){
			 alert("please enter your Salary");
			 return false;
		 }
		 
		}
			
			
		</script>
	</head>
	<body>
		<form onsubmit="return validate()" action="form_prc.php" method="POST">
			id:<input type="text" name="id" id="id"><br>
			name:<input type="text" name="name" id="name"><br>
			salary:<input type="text" name="salary" id="salary"><br>
			<input type="submit" id="submit" value="submit">
		</form>
	</body>
</html>
