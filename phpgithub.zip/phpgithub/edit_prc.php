<?php
include 'database_connection.php';

$rollno =$_REQUEST['rollno'];
$name=$_REQUEST['name'];
$phoneno=$_REQUEST['phoneno'];
$department=$_REQUEST['dept'];
$address=$_REQUEST['address'];

$sql = "update students set name='$name',phone='$phoneno',department='$department',address='$address' where roll_no=$rollno";
mysqli_query($con,$sql);

header("Location:view.php");
?>