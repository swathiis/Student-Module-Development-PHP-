<?php
	$con=mysqli_connect("localhost","root","","college");
	$sql="create table students(roll_no int,name varchar(255),phone varchar(255),department varchar(255),address varchar(255))";
	mysqli_query($con,$sql);
?>

