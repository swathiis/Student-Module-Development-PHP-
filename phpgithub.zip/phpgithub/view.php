<?php
	include 'database_connection.php';
?>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

<table border="1" cellspacing="0">
	<tr>
		<th>Roll no</th>
		<th>Name</th>
		<th>Phone no</th>
		<th>Department</th>
		<th>Address</th>
		<th>Action</th>
	</tr>

<?php
	$sql="select * from students";
	
	$res = mysqli_query($con,$sql);
	while($row = mysqli_fetch_array($res))
	{
		echo "<tr>
				<td>".$row['roll_no']."</td>
				<td>".$row['name']."</td>
				<td>".$row['phone']."</td>
				<td>".$row['department']."</td>
				<td>".$row['address']."</td>
				<td><a href=edit.php?id='".$row['roll_no']."'><i class='fas fa-edit'></i></a> &nbsp; <a href=delete.php?id='".$row['roll_no']."'><i class='material-icons'
				style='font-size:36px' 	>delete</i></a></td>
		     </tr>";
			 }
 ?>	
</table>
