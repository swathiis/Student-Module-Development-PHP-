<?php
	$con=mysqli_connect("localhost","root","");
	$sql="create database college";
	mysqli_query($con,$sql);
	
?>