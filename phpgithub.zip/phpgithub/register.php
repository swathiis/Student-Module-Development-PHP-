<html>
	<head>
		<script src="jquery/jquery.min.js"></script>
		<script src="jquery/jquery.validation.min.js"></script>
		<script src="jquery/jquery_validation-additional-methods.min.js"></script>
		
		<script>
			function change()
			{ 
			  var rollno=document.getElementById('rollno').value;	
				alert(rollno);
			  var name=document.getElementById('name').value;	
				alert(name);
			  var phoneno=document.getElementById('phoneno').value;
				alert(phoneno);
			  var department=document.getElementById('dept').value;	
				alert(department);
			 }
		</script>
	</head>

	<div>
		<h1>STUDENTS</h1>
	</div>
	<body>
	<form action="register_prc.php" method="POST">
		<table>
			<tr>
				<td>Roll.No:</td>
				<td><input type="text" name="rollno";" id="rollno"></td>
			</tr>
			<tr>
				<td>Name:</td>
				<td><input type="text" name="name";" id="name"></td>
			</tr>
			<tr>
				<td>Phone No:</td>
				<td><input type="text" name="phoneno";" id="phoneno"></td>
			</tr>
			<tr>
				<td>Department:</td>
				<td>
					<select name="dept" onchange="change();" id="dept">
						<option>CSE</option>
						<option>B.Tech</option>
						<option>BCA</option>
					</select>
				</td>
			</tr>
			<tr>
				<td>Address:</td>
				<td><textarea name="address"></textarea></td>
			</tr>
			<tr>
				<td><input type="submit" value="submit"></td>
			</tr>
		</table>
		</form>
	</body>
	
</html>