<?php
include 'database_connection.php';

$rollno =$_REQUEST['rollno'];
$name=$_REQUEST['name'];
$phoneno=$_REQUEST['phoneno'];
$department=$_REQUEST['dept'];
$address=$_REQUEST['address'];

$sql = "insert into students value($rollno,'$name','$phoneno','$department','$address')";
mysqli_query($con,$sql);

header("Location:register.php");
?>